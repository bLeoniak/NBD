public class Person {
    public String firstName;
    public String lastName;
    public int age;
    public String gender;

    public Person(String firstName, String lastName, int age, String gender){
        this.firstName = firstName;
        this.lastName = lastName;
        this.age = age;
        this.gender = gender;
    }
}